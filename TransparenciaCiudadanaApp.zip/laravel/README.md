# Transparencia Ciudadana

Plataforma Laravel para reportar fallas en servicios públicos.

## Instalación

1. Clona el repositorio
2. Ejecuta `composer install`
3. Configura `.env`
4. Ejecuta `php artisan migrate --seed`
5. Ejecuta `php artisan serve`

## Webhook N8n

Configura la URL en ReporteController.php

## Power BI

Conéctate directamente a la base de datos PostgreSQL.