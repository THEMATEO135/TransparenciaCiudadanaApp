
@extends('layout')
@section('content')
<h2>Panel de Administración</h2>
<p>Accede a los reportes ciudadanos y gestiona la información.</p>
<a href="/admin/reportes">Ver Reportes</a>
@endsection
