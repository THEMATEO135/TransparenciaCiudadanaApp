<?php
return [
'/' => ['App\\Controllers\\HomeController', 'index'],
'/admin' => ['App\\Controllers\\AdminController', 'dashboard'],
// Agrega más rutas aquí
];