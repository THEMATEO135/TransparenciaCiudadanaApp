<header>
    <h2>Transparencia Ciudadana</h2>
    <nav>
        <a href="/">Inicio</a> |
        <a href="/admin">Administración</a>
    </nav>
</header>